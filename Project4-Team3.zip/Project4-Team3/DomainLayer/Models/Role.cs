﻿namespace DomainLayer.Models
{
    public class Role : BaseEntity
    {
        public string RoleName { get; set; }

    }
}
