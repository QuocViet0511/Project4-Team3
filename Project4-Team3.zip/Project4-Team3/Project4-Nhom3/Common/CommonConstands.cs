﻿namespace Project4_Nhom3.Common
{
    public static class CommonConstands
    {
        public static string USER_SESSION = "USER_SESSION";
		public static string USER_ID_SESSION = "USER_ID_SESSION";
		public static string? ADMIN_SESSION = "ADMIN_SESSION";
        public static string? TONGTIEN_SESSION = "TONGTIEN_SESSION";
    }
}
