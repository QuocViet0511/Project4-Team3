﻿using System;

namespace Project4_Nhom3.Common
{
    [Serializable]
    public class UserLogin
    {
        public int? UserID { set; get; }
        public string? UserName { set; get; }
    }
}
